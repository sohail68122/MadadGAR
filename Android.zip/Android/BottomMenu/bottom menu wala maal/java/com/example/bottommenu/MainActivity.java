package com.example.bottommenu;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationMenu;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ImageView mIcon;
    TextView navViewTxt;

    BottomNavigationView mbottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mIcon = (ImageView) findViewById(R.id.iconView);
        navViewTxt = (TextView) findViewById(R.id.txtView);

        mbottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNav);
        mbottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @SuppressLint("ResourceType")
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.nav_dash:
                        mIcon.setImageDrawable(getResources().getDrawable(R.drawable.ic_home));
                        navViewTxt.setText("Home");
                        return true;

                    case R.id.nav_favourite:
                        mIcon.setImageDrawable(getResources().getDrawable(R.drawable.ic_warning));
                        navViewTxt.setText("Warning");
                        return true;

                    case R.id.nav_downloads:
                        mIcon.setImageDrawable(getResources().getDrawable(R.drawable.ic_dashboard));
                        navViewTxt.setText("Dashboard");
                        return true;
                }

                return false;
            }
        });

    }
}