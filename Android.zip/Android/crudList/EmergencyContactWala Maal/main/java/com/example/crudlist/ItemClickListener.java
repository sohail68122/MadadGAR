package com.example.crudlist;

public interface ItemClickListener {
    void OnItemClick(int position,UserData userData);
}
